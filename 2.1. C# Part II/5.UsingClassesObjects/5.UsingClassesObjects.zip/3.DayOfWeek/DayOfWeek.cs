﻿using System;
using System.Collections.Generic;
using System.Linq;

class DayOfWeek
{
    static void Main()
    {
        Console.WriteLine("Today is {0}", DateTime.Now.DayOfWeek);
    }
}

