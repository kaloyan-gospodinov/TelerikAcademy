﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace _0.UnitTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
