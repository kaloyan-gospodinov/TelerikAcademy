﻿using System;


class IntegerVarHex
{
    static void Main()
    {   
        //254 in hexadecimal is FE
        int hexValue = 0xFE;
        Console.WriteLine(hexValue);
    }
}

