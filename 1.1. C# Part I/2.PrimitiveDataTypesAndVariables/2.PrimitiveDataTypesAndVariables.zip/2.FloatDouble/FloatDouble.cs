﻿using System;

class FloatDouble
{
    static void Main()
    {
        double one = 34.567839023D;
        float two = 12.345F;
        double three = 8923.1234857D;
        float four = 3456.091F;

        Console.WriteLine("{0}, {1}, {2}, {3}", one, two, three, four);
    }
}

