﻿using System;



class CharVarHex
{
    static void Main()
    {   
        //72 in hexadecimal is 48
        char hexValue = '\u0048';
        Console.WriteLine(hexValue);
    }
}
