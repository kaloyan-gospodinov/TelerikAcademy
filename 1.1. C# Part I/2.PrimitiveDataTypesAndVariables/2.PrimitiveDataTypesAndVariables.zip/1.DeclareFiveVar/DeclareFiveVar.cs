﻿using System;

class DeclareFiveVar
{
    static void Main()
    {
       ushort one = 52130;
       sbyte two = -115;
       int three = 4825932;
       byte four = 97;
       short five = -10000;

       Console.WriteLine("{0}, {1}, {2}, {3}, {4}", one, two, three, four,five);
    }
}

