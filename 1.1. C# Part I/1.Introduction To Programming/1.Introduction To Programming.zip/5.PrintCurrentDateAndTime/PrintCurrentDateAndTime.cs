﻿using System;

class PrintCurrentDateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}