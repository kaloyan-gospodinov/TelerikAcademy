﻿using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Kaloyan " + "Gospodinov");
    }
}