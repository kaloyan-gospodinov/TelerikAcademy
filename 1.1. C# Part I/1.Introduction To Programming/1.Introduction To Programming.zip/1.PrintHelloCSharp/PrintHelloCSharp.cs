﻿using System;

class PrintHelloCSharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#");
    }
}